<?php

include "config.php";

if(!empty($_POST['ids']))
{
    $identity_number = $_POST['ids'];
    $sql_statement = "DELETE FROM has_insurance WHERE identity_number = $identity_number";
    $result = mysqli_query($db, $sql_statement);
    echo "Your result is " . $result;
}

?>