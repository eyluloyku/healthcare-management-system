<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>ins_id</th>
                <th>identity_number</th>
				<th>age</th>
				<th>gender</th>
				<th>weight</th>
				<th>height</th>
				
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['ins_id'])){ 
    $ins_id = $_POST['ins_id']; 
    $sql_statement = "SELECT HI.ins_id, P.identity_number, P.age, P.height, P.weight, P.gender FROM has_insurance HI, patients P WHERE p.identity_number = HI.identity_number AND HI.ins_id ='$ins_id'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
	  $ins_id = $id_rows['ins_id'];
        $identity_number = $id_rows['identity_number'];
        $age = $id_rows['age'];
	  $gender = $id_rows['gender'];
        $weight = $id_rows['weight'];
        $height = $id_rows['height'];
        echo "<tr> <td>" . $ins_id . "</td><td>" . $identity_number . "</td><td>" . $age . "</td><td>" . $gender . "</td><td>" . $weight . "</td><td>" . $height . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter insurance id.";
}
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">
