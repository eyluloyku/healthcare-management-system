<?php 

include "config.php"; 


if (!empty($_POST['ins_id']) and !empty($_POST['identity_number'])){ 
    $ins_id = $_POST['ins_id']; 
    $identity_number = $_POST['identity_number']; 
    $until = date('Y-m-d', strtotime($_POST['until']));
    $sql_statement = "INSERT INTO has_insurance(until, ins_id ,identity_number) VALUES ('$until','$ins_id', '$identity_number')"; 

    $result = mysqli_query($db, $sql_statement);
    echo "Your insertion is done.";

    include "index.php";
} 

else 
{
    echo "You did not enter insurance id or identity number!";
}

?>
