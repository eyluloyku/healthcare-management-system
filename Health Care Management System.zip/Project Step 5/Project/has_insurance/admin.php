<?php 

include "config.php";

?>

<form action="delete.php" method="POST">
<select name="ids">

<?php

$sql_command = "SELECT * FROM has_insurance";

$myresult = mysqli_query($db, $sql_command);

    while($id_rows = mysqli_fetch_assoc($myresult))
    {
        $ins_id = $id_rows['ins_id'];
        $identity_number = $id_rows['identity_number'];
	  $until = $id_rows['until'];
        echo "<option value=$identity_number>". $ins_id. " - " . $identity_number . " - " . $until ."</option>";
    }

?>

</select>
<button>DELETE</button>
</form>