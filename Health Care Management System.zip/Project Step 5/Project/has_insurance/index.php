<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>ins_id</th>
                <th>identity_number</th>
				<th>until</th>
				
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
$sql_statement = "SELECT * FROM has_insurance"; 

$result = mysqli_query($db, $sql_statement); // Executing query

while($row = mysqli_fetch_assoc($result)) { // Iterating the result
    $ins_id = $row['ins_id']; 
    $identity_number = $row['identity_number']; 
    $until = $row['until'];
    echo "<tr> <td>" . $ins_id . "</td><td>" . $identity_number . "</td><td>" . $until . "</td></tr>"; 
} 
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">
