<?php 

include "config.php"; 
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>hid</th>
				<th>location</th>
				<th>bed_capacity</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['bed_capacity'])){ 
    $bed_capacity = $_POST['bed_capacity']; 
    $sql_statement = "SELECT * FROM hospitals WHERE bed_capacity >= '$bed_capacity'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
        $hid = $id_rows['hid'];
        $location = $id_rows['location'];
        $bed_capacity = $id_rows['bed_capacity'];
        echo "<tr> <td>" . $hid . "</td><td>" . $location . "</td><td>" . $bed_capacity . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter your name.";
}

?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">

