<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>sid</th>
                <th>hid</th>
				<th>location</th>
				<th>bed_capacity</th>
				
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['sid'])){ 
    $sid = $_POST['sid']; 
    $sql_statement = "SELECT HI.sid, P.hid, P.location, P.bed_capacity FROM supplies_to HI, hospitals P WHERE p.hid= HI.hid AND HI.sid ='$sid'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
	  $hid = $id_rows['hid'];
        $location = $id_rows['location'];
        $bed_capacity = $id_rows['bed_capacity'];
	  $sid = $id_rows['sid'];
        echo "<tr> <td>" . $sid . "</td><td>" . $hid . "</td><td>" . $location . "</td><td>" . $bed_capacity . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter sid.";
}
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">
