<?php 

include "config.php"; 


if (!empty($_POST['hid']) and !empty($_POST['sid'])){ 
    $sid = $_POST['sid']; 
    $hid = $_POST['hid']; 
    $sql_statement = "INSERT INTO supplies_to(sid,hid) VALUES ($sid, $hid)"; 

    $result = mysqli_query($db, $sql_statement);
    echo "Your insertion is done.";

    include "index.php";
} 

else 
{
    echo "You did not enter sid or hid!";
}

?>
