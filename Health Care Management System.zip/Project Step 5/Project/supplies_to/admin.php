<?php 

include "config.php";

?>

<form action="delete.php" method="POST">
<select name="ids">

<?php

$sql_command = "SELECT * FROM supplies_to";

$myresult = mysqli_query($db, $sql_command);

    while($id_rows = mysqli_fetch_assoc($myresult))
    {
        $sid= $id_rows['sid'];
        $hid= $id_rows['hid'];
        echo "<option value=$sid>". $sid. " - " . $hid ."</option>";
    }

?>

</select>
<button>DELETE</button>
</form>