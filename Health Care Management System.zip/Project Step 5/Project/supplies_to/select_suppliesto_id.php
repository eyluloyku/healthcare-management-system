<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>hid</th>
                <th>sid</th>
				<th>location</th>
				
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['hid'])){ 
    $hid = $_POST['hid']; 
    $sql_statement = "SELECT HI.hid, HI.sid, I.location FROM supplies_to HI, suppliers I WHERE I.sid = HI.sid AND HI.hid ='$hid'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
        $hid = $id_rows['hid'];
        $sid = $id_rows['sid'];
        $location = $id_rows['location'];
        echo "<tr> <td>" . $hid . "</td><td>" . $sid . "</td><td>" . $location . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter hospital id.";
}
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">

