<?php 

include "config.php";

?>

<div class='box'>
<div class='upComponent'>
<div class='title'>Select the medicine to be deleted:</div>

<div class='title'>
    <img src='https://u-intosai.org/wp-content/uploads/stm_lms_avatars/stm_lms_avatar2090.jpg?v=1663764813'  class='avatar'>
        
</div>

</div>

<br>
<form action="delete.php" method="POST">
<select class="pure-material-button-contained" name="ids">


<?php

$sql_command = "SELECT * FROM medicines";

$myresult = mysqli_query($db, $sql_command);

    while($id_rows = mysqli_fetch_assoc($myresult))
    {
        $medicine_id = $id_rows['medicine_id'];
        $price = $id_rows['price'];
        $name = $id_rows['name'];
	  $expiration_date = $id_rows['expiration_date'];
	  $primary_substance = $id_rows['primary_substance'];
        echo "<option value=$medicine_id>". $price . " - " . $name. " - ". $expiration_date . " - " . $primary_substance   . "</option>";
    }

?>

</select>
<br>
<br>
<div>
<button class="pure-material-button-contained" type="submit">Delete</button>
</div>
</form>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">