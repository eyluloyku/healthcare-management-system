<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>medicine_id</th>
				<th>price</th>
				<th>name</th>
				<th>expiration_date</th>
				<th>primary_substance</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
$sql_statement = "SELECT * FROM medicines"; 

$result = mysqli_query($db, $sql_statement); // Executing query

while($row = mysqli_fetch_assoc($result)) { // Iterating the result
    $medicine_id = $row['medicine_id']; 
    $price= $row['price']; 
    $name = $row['name'];
    $expiration_date =  $row['expiration_date'];
    $primary_substance =  $row['primary_substance'];
    echo "<tr> <td>" . $medicine_id . "</td><td>" . $price . "</td><td>" . $name . "</td><td>" . $expiration_date . "</td><td>" . $primary_substance . "</td></tr>"; 
} 

?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">

