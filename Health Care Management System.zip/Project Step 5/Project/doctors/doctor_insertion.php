<?php 

include "config.php"; 

if (!empty($_POST['ssn'])){ 
    $ssn = $_POST['ssn']; 
    $title = $_POST['title']; 
    $age = $_POST['age']; 
    $sql_statement = "INSERT INTO doctors(ssn, title, age) VALUES ($ssn,'$title',$age)"; 

    $result = mysqli_query($db, $sql_statement);
    echo "<div class='box'>
<div class='upComponent'>
                <div class='title'>Doctor Instertion Result</div>
        
                <div class='title'>
                    <img src='https://u-intosai.org/wp-content/uploads/stm_lms_avatars/stm_lms_avatar2090.jpg?v=1663764813'  class='avatar'>
                        
                </div>

            </div>
        
            <br>
            <h2>Doctor inserted successfully</h2>
    
    
    <h2>Your result is: " . $result . "</h2></div>";
} 

?>

<?php 

include "delete_doctors.php"; 
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Instert</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">