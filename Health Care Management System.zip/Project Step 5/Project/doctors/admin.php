<?php 

include "config.php";

?>
<div class='box'>
<div class='upComponent'>
<div class='title'>Select the doctor to be deleted:</div>

<div class='title'>
    <img src='https://u-intosai.org/wp-content/uploads/stm_lms_avatars/stm_lms_avatar2090.jpg?v=1663764813'  class='avatar'>
        
</div>

</div>

<br>
<form action="delete_doctors.php" method="POST">
<select class="pure-material-button-contained" name="ids">



<?php

$sql_command = "SELECT ssn, title, age FROM doctors";

$myresult = mysqli_query($db, $sql_command);

    while($id_rows = mysqli_fetch_assoc($myresult))
    {
        $ssn = $id_rows['ssn'];
        $title = $id_rows['title'];
        $age = $id_rows['age'];
        echo "<option value=$ssn>". $ssn. " - " . $title . " - " . $age . "</option>";
    }

?>

</select>
<br>
<br>
<div>
<button class="pure-material-button-contained" type="submit">Delete</button>
</div>
</form>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">