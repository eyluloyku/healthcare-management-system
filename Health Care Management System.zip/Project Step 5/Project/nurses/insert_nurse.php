<?php 

include "config.php"; 

if (!empty($_POST['ssn'])){ 
    $ssn = $_POST['ssn']; 
    $age = $_POST['age']; 
    $gender = $_POST['gender']; 
    $sql_statement = "INSERT INTO nurses VALUES ($ssn, $age , '$gender')"; 

    $result = mysqli_query($db, $sql_statement);
    echo "<div class='box'>
    <div class='upComponent'>
                    <div class='title'>Nurse Insertion Result</div>
            
                    <div class='title'>
                        <img src='https://u-intosai.org/wp-content/uploads/stm_lms_avatars/stm_lms_avatar2090.jpg?v=1663764813'  class='avatar'>
                            
                    </div>
    
                </div>
            
                <br>
                <h2>Nurse Inserted successfully</h2>
        
        
        <h2>Your result is: " . $result . "</h2></div>";
    } 
else 
{
    echo "You did not enter ssn.";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Instert</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">