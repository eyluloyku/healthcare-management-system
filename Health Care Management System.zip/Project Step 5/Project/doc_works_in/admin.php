<?php 

include "config.php";

?>

<form action="delete.php" method="POST">
<select name="ids">

<?php

$sql_command = "SELECT did, ssn, since FROM doc_works_in";

$myresult = mysqli_query($db, $sql_command);

    while($id_rows = mysqli_fetch_assoc($myresult))
    {
        $did = $id_rows['did'];
        $ssn = $id_rows['ssn'];
	  $since = $id_rows['since'];
        echo "<option value=$ssn>". $did. " - " . $ssn . " - " . $since ."</option>";
    }

?>

</select>
<button>DELETE</button>
</form>