<?php

include "config.php";

if(!empty($_POST['ids']))
{
    $ssn = $_POST['ids'];
    $sql_statement = "DELETE FROM doc_works_in WHERE ssn = $ssn";
    $result = mysqli_query($db, $sql_statement);
    echo "Your result is " . $result;
}

?>