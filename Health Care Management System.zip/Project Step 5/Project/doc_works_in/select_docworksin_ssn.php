<?php 
include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>hid</th>
				<th>did</th>
				<th>name</th>
				<th>ssn</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['ssn'])){ 
    $ssn = $_POST['ssn']; 
    $sql_statement = "SELECT DW.ssn, Dep.hid, DW.did, Dep.name FROM departments Dep, doc_works_in DW WHERE Dep.did = DW.did AND DW.ssn ='$ssn'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
        $hid = $id_rows['hid'];
        $did = $id_rows['did'];
        $name = $id_rows['name'];
	  $ssn = $id_rows['ssn'];
        echo "<tr> <td>" . $hid . "</td><td>" . $did . "</td><td>" . $name . "</td><td>" . $ssn . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter doctor ssn.";
}
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">

