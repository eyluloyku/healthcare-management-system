<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>did</th>
				<th>ssn</th>
				<th>since</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
$sql_statement = "SELECT * FROM doc_works_in"; 

$result = mysqli_query($db, $sql_statement); // Executing query

while($row = mysqli_fetch_assoc($result)) { // Iterating the result
    $did = $row['did']; 
    $ssn = $row['ssn']; 
    $since = $row['since'];
    echo "<tr> <td>" . $did . "</td><td>" . $ssn . "</td><td>" . $since . "</td></tr>"; 
} 
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">

