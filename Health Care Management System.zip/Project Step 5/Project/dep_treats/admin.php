<?php 

include "config.php";

?>

<form action="delete.php" method="POST">
<select name="ids">

<?php

$sql_command = "SELECT did, name FROM dep_treats";

$myresult = mysqli_query($db, $sql_command);

    while($id_rows = mysqli_fetch_assoc($myresult))
    {
        $did = $id_rows['did'];
        $name = $id_rows['name'];
        echo "<option value=$did>". $did. " - " . $name . "</option>";
    }

?>

</select>
<button>DELETE</button>
</form>