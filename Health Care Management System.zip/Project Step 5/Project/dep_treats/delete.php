<?php

include "config.php";

if(!empty($_POST['ids']))
{
    $did = $_POST['ids'];
    $sql_statement = "DELETE FROM dep_treats WHERE did = $did";
    $result = mysqli_query($db, $sql_statement);
    echo "Your result is " . $result;
}

?>