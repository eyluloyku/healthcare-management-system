<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>hid</th>
                <th>did</th>
				<th>Department Name</th>
				<th>Disease Name</th>
				
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['name'])){ 
    $name = $_POST['name']; 
    $sql_statement = "SELECT Dep.hid, Dep.did, Dep.name AS 'Department Name', DT.name AS 'Disease Name' FROM departments Dep, dep_treats DT WHERE Dep.did = DT.did AND DT.name ='$name'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
        $hid = $id_rows['hid'];
        $did = $id_rows['did'];
        $dep_name = $id_rows['Department Name'];
	  $dis_name = $id_rows['Disease Name'];
        echo "<tr> <td>" . $hid . "</td><td>" . $did . "</td><td>" . $dep_name . "</td><td>" . $dis_name . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter disease name.";
}
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">
