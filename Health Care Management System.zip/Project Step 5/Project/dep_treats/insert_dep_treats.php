<?php 

include "config.php"; 


if (!empty($_POST['did']) and !empty($_POST['name'])){ 
    $did = $_POST['did']; 
    $name = $_POST['name']; 
    $sql_statement = "INSERT INTO dep_treats(did,name) VALUES ($did,'$name')"; 

    $result = mysqli_query($db, $sql_statement);
    echo "Your insertion is done.";

    include "index.php";
} 

else 
{
    echo "You did not enter department id or disease name!";
}

?>
