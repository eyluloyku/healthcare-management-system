<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>did</th>
				<th>Department Name</th>
				<th>Disease Name</th>
				<th>contagious</th>
				<th>treatment</th>
				<th>chronic</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['did'])){ 
    $did = $_POST['did']; 
    $sql_statement = "SELECT DT. did, Dep.name AS 'Department Name', Dis.name AS 'Disease Name', contagious, treatment, chronic FROM diseases Dis, dep_treats DT, departments Dep WHERE Dis.name = DT.name AND DT.did = Dep.did AND DT.did ='$did'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
	  $did = $id_rows['did'];
        $dep_name = $id_rows['Department Name'];
        $dis_name = $id_rows['Disease Name'];
	  $contagious = $id_rows['contagious'];
        $treatment = $id_rows['treatment'];
        $chronic = $id_rows['chronic'];
        echo "<tr> <td>" . $did . "</td><td>" . $dep_name . "</td><td>" . $dis_name . "</td><td>" . $contagious . "</td><td>" . $treatment .. "</td><>" . $chronic . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter department id.";
}
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">
