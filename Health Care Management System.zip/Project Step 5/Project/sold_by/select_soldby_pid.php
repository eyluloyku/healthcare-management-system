<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>name</th>
                <th>medicine_id</th>
				<th>price</th>
				<th>pid</th>
				<th>primary_substance</th>
				<th>expiration_date</th>
				
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['pid'])){ 
    $pid = $_POST['pid']; 
    $sql_statement = "SELECT HI.pid, P.medicine_id, P.price, P.name, P.primary_substance, P.expiration_date FROM sold_by HI, medicines P WHERE p.medicine_id = HI.medicine_id AND HI.pid ='$pid'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
	  $name = $id_rows['name'];
        $medicine_id = $id_rows['medicine_id'];
        $price = $id_rows['price'];
	  $pid = $id_rows['pid'];
        $primary_substance = $id_rows['primary_substance'];
        $expiration_date = $id_rows['expiration_date'];
        echo "<tr> <td>" . $name . "</td><td>" . $medicine_id . "</td><td>" . $price . "</td><td>" . $pid . "</td><td>" . $primary_substance . "</td><td>" . $expiration_date . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter pid.";
}
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">
