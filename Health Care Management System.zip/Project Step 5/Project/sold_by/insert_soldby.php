<?php 

include "config.php"; 


if (!empty($_POST['medicine_id']) and !empty($_POST['pid'])){ 
    $pid = $_POST['pid']; 
    $medicine_id = $_POST['medicine_id']; 
    $sql_statement = "INSERT INTO sold_by(medicine_id,pid) VALUES ($medicine_id, $pid)"; 

    $result = mysqli_query($db, $sql_statement);
    echo "Your insertion is done.";

    include "index.php";
} 

else 
{
    echo "You did not enter pid or medicine_id!";
}

?>
