<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>pid</th>
                <th>medicine_id</th>
				<th>location</th>
				
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['medicine_id'])){ 
    $medicine_id = $_POST['medicine_id']; 
    $sql_statement = "SELECT HI.medicine_id, HI.pid, I.location FROM sold_by HI, pharmacies I WHERE I.pid = HI.pid AND HI.medicine_id ='$medicine_id'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
        $pid = $id_rows['pid'];
        $medicine_id = $id_rows['medicine_id'];
        $location = $id_rows['location'];
        echo "<tr> <td>" . $pid . "</td><td>" . $medicine_id . "</td><td>" . $location . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter medicine_id.";
}
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">
