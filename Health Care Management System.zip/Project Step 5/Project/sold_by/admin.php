<?php 

include "config.php";

?>

<form action="delete.php" method="POST">
<select name="ids">

<?php

$sql_command = "SELECT * FROM sold_by";

$myresult = mysqli_query($db, $sql_command);

    while($id_rows = mysqli_fetch_assoc($myresult))
    {
        $pid= $id_rows['pid'];
        $medicine_id = $id_rows['medicine_id'];
        echo "<option value=$pid>". $medicine_id. " - " . $pid ."</option>";
    }

?>

</select>
<button>DELETE</button>
</form>