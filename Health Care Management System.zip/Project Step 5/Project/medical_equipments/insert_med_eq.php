<?php 

include "config.php"; 

if (!empty($_POST['mid'])){ 
    $mid = $_POST['mid']; 
    $expiration_date = date('Y-m-d', strtotime($_POST['expiration_date']));

    $price = $_POST['price'];
    $type = $_POST['type']; 
    $sql_statement = "INSERT INTO medical_equipments(mid, expiration_date, price, type) VALUES ($mid,'$expiration_date', $price, '$type')"; 

    $result = mysqli_query($db, $sql_statement);
    echo "<div class='box'>
    <div class='upComponent'>
                    <div class='title'>medical_equipment Insertion Result</div>
            
                    <div class='title'>
                        <img src='https://u-intosai.org/wp-content/uploads/stm_lms_avatars/stm_lms_avatar2090.jpg?v=1663764813'  class='avatar'>
                            
                    </div>
    
                </div>
            
                <br>
                <h2>medical_equipment Inserted successfully</h2>
        
        
        <h2>Your result is: " . $result . "</h2></div>";
    } 
else 
{
    echo "You did not enter medical equipment id.";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Instert</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">
