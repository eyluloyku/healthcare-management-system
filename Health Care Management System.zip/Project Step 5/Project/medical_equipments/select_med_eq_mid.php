<?php 

include "config.php"; 
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>mid</th>
				<th>expiration_date</th>
				<th>price</th>
				<th>type</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['mid'])){ 
    $mid = $_POST['mid']; 
    $sql_statement = "SELECT * FROM medical_equipments WHERE mid = '$mid'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
        $mid = $id_rows['mid'];
        $expiration_date = $id_rows['expiration_date'];
        $price = $id_rows['price'];
	    $type = $id_rows['type'];
        echo "<tr> <td>" . $mid . "</td><td>" . $expiration_date . "</td><td>" . $price . "</td><td>" . $type . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter ID.";
}

?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">


