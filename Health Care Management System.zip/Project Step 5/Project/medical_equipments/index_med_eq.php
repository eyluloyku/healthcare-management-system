<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>mid</th>
				<th>expiration_date</th>
				<th>price</th>
				<th>type</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
$sql_statement = "SELECT * FROM medical_equipments"; 

$result = mysqli_query($db, $sql_statement); // Executing query

while($row = mysqli_fetch_assoc($result)) { // Iterating the result
    $mid = $row['mid']; 
    $expiration_date = $row['expiration_date']; 
    $price = $row['price'];
    $type = $row['type'];   
    echo "<tr> <td>" . $mid . "</td><td>" . $expiration_date . "</td><td>" . $price . "</td><td>" . $type . "</td></tr>"; 
} 

?>


</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">


