<?php

include "config.php";

if(!empty($_POST['ids']))
{
    $mid = $_POST['ids'];
    $sql_statement = "DELETE FROM medical_equipments WHERE mid = $mid";
    $result = mysqli_query($db, $sql_statement);
    echo "<div class='box'>
    <div class='upComponent'>
                    <div class='title'>medical_equipment Deletion Result</div>
            
                    <div class='title'>
                        <img src='https://u-intosai.org/wp-content/uploads/stm_lms_avatars/stm_lms_avatar2090.jpg?v=1663764813'  class='avatar'>
                            
                    </div>
    
                </div>
            
                <br>
                <h2>medical_equipment Deletion successfully</h2>
        
        
        <h2>Your result is: " . $result . "</h2></div>";
    } 

?>