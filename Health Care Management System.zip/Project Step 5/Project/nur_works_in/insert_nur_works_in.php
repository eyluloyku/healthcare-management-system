<?php 

include "config.php"; 


if (!empty($_POST['did']) and !empty($_POST['ssn'])){ 
    $did = $_POST['did']; 
    $ssn = $_POST['ssn']; 
    $since = date('Y-m-d', strtotime($_POST['since']));
    $sql_statement = "INSERT INTO nur_works_in(since, ssn ,did) VALUES ('$since','$ssn', '$did')"; 

    $result = mysqli_query($db, $sql_statement);
    echo "Your insertion is done.";

    include "index.php";
} 

else 
{
    echo "You did not enter department id or nurse ssn!";
}

?>
