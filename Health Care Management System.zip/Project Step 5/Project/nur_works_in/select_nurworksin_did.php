<?php 
include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>did</th>
				<th>name</th>
				<th>ssn</th>
				<th>gender</th>
				<th>age</th>
				<th>since</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['did'])){ 
    $did = $_POST['did']; 
    $sql_statement = "SELECT DW.did, Dep.name, DW.ssn, Doc.gender, Doc.age, DW.since FROM nurses Doc, nur_works_in DW, departments Dep WHERE Doc.ssn = DW.ssn AND DW.did = Dep.did AND DW.did ='$did'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
	  $did = $id_rows['did'];
        $name = $id_rows['name'];
        $ssn = $id_rows['ssn'];
	  $gender = $id_rows['gender'];
        $age = $id_rows['age'];
        $since = $id_rows['since'];
        echo "<tr> <td>" . $did . "</td><td>" . $name . "</td><td>" . $ssn . "</td><td>" . $gender . "</td><td>" . $age . "</td><td>" . $since . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter department id.";
}
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">

