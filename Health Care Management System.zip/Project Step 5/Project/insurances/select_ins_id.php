<?php 

include "config.php"; 
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>ins_id</th>
				<th>type</th>
				<th>price</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['ins_id'])){ 
    $ins_id = $_POST['ins_id']; 
    $sql_statement = "SELECT * FROM insurances WHERE ins_id = '$ins_id'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
        $ins_id = $id_rows['ins_id'];
        $type = $id_rows['type'];
        $price = $id_rows['price'];
        echo "<tr> <td>" . $ins_id . "</td><td>" . $type . "</td><td>" . $price . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter your name.";
}
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">

