<?php 

include "config.php"; 


if (!empty($_POST['hid']) and !empty($_POST['ssn'])){ 
    $hid = $_POST['hid']; 
    $ssn = $_POST['ssn']; 
    $since = date('Y-m-d', strtotime($_POST['since']));
    $sql_statement = "INSERT INTO staff_works_in(since, ssn ,hid) VALUES ('$since','$ssn', '$hid')"; 

    $result = mysqli_query($db, $sql_statement);
    echo "Your insertion is done.";

    include "index.php";
} 

else 
{
    echo "You did not enter hospital id or staff ssn!";
}

?>
