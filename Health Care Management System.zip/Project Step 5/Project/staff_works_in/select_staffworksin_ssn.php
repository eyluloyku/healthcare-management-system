<?php 
include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>hid</th>
				<th>ssn</th>
				<th>location</th>
				<th>bed_capacity</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['ssn'])){ 
    $ssn = $_POST['ssn']; 
    $sql_statement = "SELECT DW.ssn, Dep.hid, Dep.location, Dep.bed_capacity FROM hospitals Dep, staff_works_in DW WHERE Dep.hid = DW.hid AND DW.ssn ='$ssn'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
        $hid = $id_rows['hid'];
        $ssn = $id_rows['ssn'];
        $location = $id_rows['location'];
	  $bed_capacity = $id_rows['bed_capacity'];
      echo "<tr> <td>" . $hid . "</td><td>" . $ssn . "</td><td>" . $location . "</td><td>" . $bed_capacity  . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter staff ssn.";
}
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">


