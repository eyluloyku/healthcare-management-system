<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>hid</th>
				<th>location</th>
				<th>ssn</th>
				<th>gender</th>
				<th>age</th>
				<th>since</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['hid'])){ 
    $hid = $_POST['hid']; 
    $sql_statement = "SELECT DW.hid, Dep.location, DW.ssn, Doc.gender, Doc.age, DW.since FROM non_medical_staff Doc, staff_works_in DW, hospitals Dep WHERE Doc.ssn = DW.ssn AND DW.hid = Dep.hid AND DW.hid ='$hid'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
	  $hid = $id_rows['hid'];
        $location = $id_rows['location'];
        $ssn = $id_rows['ssn'];
	  $gender = $id_rows['gender'];
        $age = $id_rows['age'];
        $since = $id_rows['since'];
        echo "<tr> <td>" . $hid . "</td><td>" . $location . "</td><td>" . $ssn . "</td><td>" . $gender . "</td><td>" . $age . "</td><td>" . $since . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter hospital id.";
}
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">
