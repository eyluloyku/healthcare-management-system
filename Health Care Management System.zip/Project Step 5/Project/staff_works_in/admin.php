<?php 

include "config.php";

?>

<form action="delete.php" method="POST">
<select name="ids">

<?php

$sql_command = "SELECT hid, ssn, since FROM staff_works_in";

$myresult = mysqli_query($db, $sql_command);

    while($id_rows = mysqli_fetch_assoc($myresult))
    {
        $hid = $id_rows['hid'];
        $ssn = $id_rows['ssn'];
	  $since = $id_rows['since'];
        echo "<option value=$ssn>". $hid. " - " . $ssn . " - " . $since ."</option>";
    }

?>

</select>
<button>DELETE</button>
</form>