<?php

include "config.php";

if(!empty($_POST['ids']))
{
    $sid = $_POST['ids'];
    $sql_statement = "DELETE FROM supplies WHERE sid= $sid";
    $result = mysqli_query($db, $sql_statement);
    echo "Your result is " . $result;
}

?>