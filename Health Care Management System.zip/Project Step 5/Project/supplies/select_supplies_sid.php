<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>type</th>
                <th>mid</th>
				<th>price</th>
				<th>sid</th>
				<th>expiration_date</th>
				
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['sid'])){ 
    $sid = $_POST['sid']; 
    $sql_statement = "SELECT HI.sid, P.mid, P.price, P.type, P.expiration_date FROM supplies HI, medical_equipments P WHERE p.mid= HI.mid AND HI.sid ='$sid'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
	  $type = $id_rows['type'];
        $mid = $id_rows['mid'];
        $price = $id_rows['price'];
	  $sid = $id_rows['sid'];
        $expiration_date = $id_rows['expiration_date'];
        echo "<tr> <td>" . $type . "</td><td>" . $mid . "</td><td>" . $price . "</td><td>" . $sid . "</td><td>" . $expiration_date . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter sid.";
}
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">
