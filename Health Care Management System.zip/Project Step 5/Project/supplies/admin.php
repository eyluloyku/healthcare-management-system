<?php 

include "config.php";

?>

<form action="delete.php" method="POST">
<select name="ids">

<?php

$sql_command = "SELECT * FROM supplies";

$myresult = mysqli_query($db, $sql_command);

    while($id_rows = mysqli_fetch_assoc($myresult))
    {
        $sid= $id_rows['sid'];
        $mid= $id_rows['mid'];
        echo "<option value=$sid>". $sid. " - " . $mid ."</option>";
    }

?>

</select>
<button>DELETE</button>
</form>