<?php 

include "config.php"; 


if (!empty($_POST['mid']) and !empty($_POST['sid'])){ 
    $sid = $_POST['sid']; 
    $mid = $_POST['mid']; 
    $sql_statement = "INSERT INTO supplies(mid,sid) VALUES ($mid, $sid)"; 

    $result = mysqli_query($db, $sql_statement);
    echo "Your insertion is done.";

    include "index.php";
} 

else 
{
    echo "You did not enter sid or mid!";
}

?>
