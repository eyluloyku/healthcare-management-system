<?php 

include "config.php"; 


if (!empty($_POST['identity_number']) and !empty($_POST['name'])){ 
    $name = $_POST['name']; 
    $identity_number = $_POST['identity_number']; 
    $since = date('Y-m-d', strtotime($_POST['since']));
    $sql_statement = "INSERT INTO has_disease(since,identity_number,name) VALUES ('$since', '$identity_number', '$name')"; 

    $result = mysqli_query($db, $sql_statement);
    echo "Your insertion is done.";

    include "index.php";
} 

else 
{
    echo "You did not enter name or identity number!";
}

?>
