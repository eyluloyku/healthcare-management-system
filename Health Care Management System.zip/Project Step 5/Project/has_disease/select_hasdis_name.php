<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>name</th>
                <th>identity_number</th>
				<th>age</th>
				<th>gender</th>
				<th>weight</th>
				<th>height</th>
				
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['name'])){ 
    $name = $_POST['name']; 
    $sql_statement = "SELECT HI.name, P.identity_number, P.age, P.height, P.weight, P.gender FROM has_disease HI, patients P WHERE p.identity_number = HI.identity_number AND HI.name ='$name'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
	  $name = $id_rows['name'];
        $identity_number = $id_rows['identity_number'];
        $age = $id_rows['age'];
	  $gender = $id_rows['gender'];
        $weight = $id_rows['weight'];
        $height = $id_rows['height'];
        echo "<tr> <td>" . $name . "</td><td>" . $identity_number . "</td><td>" . $age . "</td><td>" . $gender . "</td><td>" . $weight . "</td><td>" . $height . "</td></tr>";
    }

} 
else 
{
    echo "You did not enter name.";
}
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">
