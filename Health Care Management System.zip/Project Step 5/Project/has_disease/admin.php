<?php 

include "config.php";

?>

<form action="delete.php" method="POST">
<select name="ids">

<?php

$sql_command = "SELECT identity_number, name, since FROM has_disease";

$myresult = mysqli_query($db, $sql_command);

    while($id_rows = mysqli_fetch_assoc($myresult))
    {
        $name= $id_rows['name'];
        $identity_number = $id_rows['identity_number'];
	  $since = $id_rows['since'];
        echo "<option value=$identity_number>". $identity_number. " - " . $name . " - " . $since ."</option>";
    }

?>

</select>
<button>DELETE</button>
</form>