<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>name</th>
                <th>identity_number</th>
				<th>contagious</th>
				<th>treatment</th>
				<th>chronic</th>
				
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['identity_number'])){ 
    $identity_number = $_POST['identity_number']; 
    $sql_statement = "SELECT HI.identity_number, HI.name, I.contagious, I.treatment, I.chronic FROM has_disease HI, diseases I WHERE I.name = HI.name AND HI.identity_number ='$identity_number'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
        $name = $id_rows['name'];
        $identity_number = $id_rows['identity_number'];
        $contagious = $id_rows['contagious'];
	  $treatment = $id_rows['treatment'];
        $chronic = $id_rows['chronic'];
        echo "<tr> <td>" . $name . "</td><td>" . $identity_number . "</td><td>" . $contagious . "</td><td>" . $treatment . "</td><td>" . $chronic . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter identity number.";
}
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">
