<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>did</th>
				<th>hid</th>
				<th>name</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['name'])){ 
    $name = $_POST['name']; 
    $sql_statement = "SELECT * FROM departments WHERE name = '$name'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
        $did = $id_rows['did'];
        $hid = $id_rows['hid'];
        $name = $id_rows['name'];
        echo "<tr> <td>" . $did . "</td><td>" . $hid . "</td><td>" . $name . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter your name.";
}

?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">


