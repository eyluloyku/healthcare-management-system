<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>did</th>
				<th>hid</th>
				<th>name</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['hid'])){ 
    $hid = $_POST['hid']; 
    $sql_statement = "SELECT * FROM departments WHERE hid = '$hid'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
        $did = $id_rows['did'];
        $name = $id_rows['name'];
        $hid = $id_rows['hid'];
        echo "<tr> <td>" . $did . "</td><td>" . $hid . "</td><td>" . $name . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter your name.";
}

?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">


