<?php 

include "config.php"; 

if (!empty($_POST['did'])){ 
    $did = $_POST['did']; 
    $hid = $_POST['hid']; 
    $name = $_POST['name']; 
    $sql_statement = "INSERT INTO departments(did, hid, name) VALUES ($did, $hid , '$name')"; 

    $result = mysqli_query($db, $sql_statement);
    echo "Your result is: " . $result;
} 
else 
{
    echo "You did not enter hospital id.";
}

?>
