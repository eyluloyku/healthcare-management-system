<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>name</th>
                <th>medicine_id</th>
				<th>contagious</th>
				<th>treatment</th>
				<th>chronic</th>
				
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['medicine_id'])){ 
    $medicine_id = $_POST['medicine_id']; 
    $sql_statement = "SELECT HI.medicine_id, HI.name, I.contagious, I.treatment, I.chronic FROM med_treates HI, diseases I WHERE I.name = HI.name AND HI.medicine_id ='$medicine_id'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
        $name = $id_rows['name'];
        $medicine_id = $id_rows['medicine_id'];
        $contagious = $id_rows['contagious'];
	  $treatment = $id_rows['treatment'];
        $chronic = $id_rows['chronic'];
        echo "<tr> <td>" . $name . "</td><td>" . $medicine_id . "</td><td>" . $contagious . "</td><td>" . $treatment . "</td><td>" . $chronic . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter medicine_id.";
}
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">
