<?php

include "config.php";

if(!empty($_POST['ids']))
{
    $medicine_id = $_POST['ids'];
    $sql_statement = "DELETE FROM med_treates WHERE medicine_id = $medicine_id";
    $result = mysqli_query($db, $sql_statement);
    echo "Your result is " . $result;
}

?>