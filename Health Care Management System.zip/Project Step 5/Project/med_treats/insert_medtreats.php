<?php 

include "config.php"; 


if (!empty($_POST['medicine_id']) and !empty($_POST['name'])){ 
    $name = $_POST['name']; 
    $medicine_id = $_POST['medicine_id']; 
    $sql_statement = "INSERT INTO med_treates(medicine_id,name) VALUES ($medicine_id, '$name')"; 

    $result = mysqli_query($db, $sql_statement);
    echo "Your insertion is done.";

    include "index.php";
} 

else 
{
    echo "You did not enter name or medicine_id!";
}

?>
