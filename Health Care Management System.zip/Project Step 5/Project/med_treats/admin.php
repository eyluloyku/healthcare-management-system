<?php 

include "config.php";

?>

<form action="delete.php" method="POST">
<select name="ids">

<?php

$sql_command = "SELECT * FROM med_treates";

$myresult = mysqli_query($db, $sql_command);

    while($id_rows = mysqli_fetch_assoc($myresult))
    {
        $name= $id_rows['name'];
        $medicine_id = $id_rows['medicine_id'];
        echo "<option value=$medicine_id>". $medicine_id. " - " . $name ."</option>";
    }

?>

</select>
<button>DELETE</button>
</form>