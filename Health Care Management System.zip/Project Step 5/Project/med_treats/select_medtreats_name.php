<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>name</th>
                <th>medicine_id</th>
				<th>price</th>
				<th>Dname</th>
				<th>primary_substance</th>
				<th>expiration_date</th>
				
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['name'])){ 
    $name = $_POST['name']; 
    $sql_statement = "SELECT HI.name AS Dname, P.medicine_id, P.price, P.name, P.primary_substance, P.expiration_date FROM med_treates HI, medicines P WHERE p.medicine_id = HI.medicine_id AND HI.name ='$name'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
	  $name = $id_rows['name'];
        $medicine_id = $id_rows['medicine_id'];
        $price = $id_rows['price'];
	  $Dname = $id_rows['Dname'];
        $primary_substance = $id_rows['primary_substance'];
        $expiration_date = $id_rows['expiration_date'];
        echo "<tr> <td>" . $name . "</td><td>" . $medicine_id . "</td><td>" . $price . "</td><td>" . $Dname . "</td><td>" . $primary_substance . "</td><td>" . $expiration_date . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter name.";
}
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">
