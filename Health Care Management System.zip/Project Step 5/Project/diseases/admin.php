<?php 

include "config.php";

?>

<div class='box'>
<div class='upComponent'>
<div class='title'>Select the disease to be deleted:</div>

<div class='title'>
    <img src='https://u-intosai.org/wp-content/uploads/stm_lms_avatars/stm_lms_avatar2090.jpg?v=1663764813'  class='avatar'>
        
</div>

</div>

<br>
<form action="delete_disease.php" method="POST">
<select class="pure-material-button-contained" name="ids">
<?php

$sql_command = "SELECT * FROM diseases";

$myresult = mysqli_query($db, $sql_command);

    while($id_rows = mysqli_fetch_assoc($myresult))
    {
        $name = $id_rows['name'];
        $contagious = $id_rows['contagious'];
        $treatment = $id_rows['treatment'];
        $chronic = $id_rows['chronic'];
        echo "<option value=$name>". $name. " - " . $contagious . " - " . "treatment" . " - " . "chronic" . "</option>";
    }

?>
</select>
<br>
<br>
<div>
<button class="pure-material-button-contained" type="submit">Delete</button>
</div>
</form>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">