<?php 

include "config.php"; // Makes mysql connection

?>
<div class='box'>


<table>
    <thead>
        <tr>
            <th>name</th>
            <th>contagious</th>
            <th>treatment</th>
            <th>chronic</th>
        </tr>
    </thead>
    <tbody>
    <tr>
               

    <?php

    $sql_statement = "SELECT * FROM diseases"; 

    $result = mysqli_query($db, $sql_statement); // Executing query

    while($row = mysqli_fetch_assoc($result)) { // Iterating the result
        $name = $row['name']; 
        $contagious = $row['contagious']; 
        $treatment = $row['treatment']; 
        $chronic = $row['chronic']; 
        echo "<tr> <td>" . $name . "</td><td>" . $contagious . "</td><td>" . $treatment . "</td><td>" . $chronic . "</td></tr>"; 
    } 

    ?>


    </tbody>
        </table>
    </div>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Doc&Delete</title>
        <link rel="stylesheet" href="style_hospital_insertion.css">


