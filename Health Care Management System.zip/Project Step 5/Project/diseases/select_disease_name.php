<?php 

include "config.php"; 

?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>name</th>
				<th>contagious</th>
				<th>treatment</th>
				<th>chronic</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php

if (!empty($_POST['name'])){ 
    $name = $_POST['name']; 
    $sql_statement = "SELECT * FROM diseases WHERE name = '$name'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
        $name = $id_rows['name'];
        $contagious = $id_rows['contagious'];
        $treatment = $id_rows['treatment'];
	  $chronic = $id_rows['chronic'];
        echo "<tr> <td>" . $name . "</td><td>" . $contagious . "</td><td>" . $treatment . "</td><td>" . $chronic . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter your name.";
}

?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">


