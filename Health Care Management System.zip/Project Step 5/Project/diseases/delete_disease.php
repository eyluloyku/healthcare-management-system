<?php

include "config.php";

if(!empty($_POST['ids']))
{
    $name = $_POST['ids'];
    $sql_statement = "DELETE FROM diseases WHERE name = '$name'";
    $result = mysqli_query($db, $sql_statement);
    echo "<div class='box'>
<div class='upComponent'>
                <div class='title'>Disease Deletetion Result</div>
        
                <div class='title'>
                    <img src='https://u-intosai.org/wp-content/uploads/stm_lms_avatars/stm_lms_avatar2090.jpg?v=1663764813'  class='avatar'>
                        
                </div>

            </div>
        
            <br>
            <h2>Disease deleted successfully</h2>
    
    
    <h2>Your result is: " . $result . "</h2></div>";
} 


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Instert</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">