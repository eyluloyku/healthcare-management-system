<?php 

include "config.php"; 

if (!empty($_POST['name'])){ 
    $name = $_POST['name']; 
    $contagious = $_POST['contagious']; 
    $treatment = $_POST['treatment']; 
    $chronic = $_POST['chronic']; 
    $sql_statement = "INSERT INTO diseases(name, contagious, treatment, chronic) VALUES ('$name',$contagious,'$treatment', $chronic)"; 

    $result = mysqli_query($db, $sql_statement);
    echo "<div class='box'>
    <div class='upComponent'>
                    <div class='title'>Disease Instertion Result</div>
            
                    <div class='title'>
                        <img src='https://u-intosai.org/wp-content/uploads/stm_lms_avatars/stm_lms_avatar2090.jpg?v=1663764813'  class='avatar'>
                            
                    </div>
    
                </div>
            
                <br>
                <h2>Disease inserted successfully</h2>
        
        
        <h2>Your result is: " . $result . "</h2></div>";
    } 
else 
{
    echo "You did not enter disease name.";
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Instert</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">