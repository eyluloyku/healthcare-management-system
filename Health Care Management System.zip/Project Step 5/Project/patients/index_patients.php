<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>identity_number</th>
				<th>age</th>
				<th>height</th>
				<th>weight</th>
				<th>gender</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
$sql_statement = "SELECT * FROM patients"; 

$result = mysqli_query($db, $sql_statement); // Executing query

while($row = mysqli_fetch_assoc($result)) { // Iterating the result
    $identity_number = $row['identity_number']; 
    $age = $row['age']; 
    $height = $row['height'];
    $weight = $row['weight'];
    $gender = $row['gender']; 
    echo "<tr> <td>" . $identity_number . "</td><td>" . $age . "</td><td>" . $height . "</td><td>" . $weight . "</td><td>" . $gender . "</td></tr>"; 
} 
?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">

