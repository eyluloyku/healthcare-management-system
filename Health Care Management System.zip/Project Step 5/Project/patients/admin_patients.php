<?php 

include "config.php";

?>

<div class='box'>
<div class='upComponent'>
<div class='title'>Select the patient to be deleted:</div>

<div class='title'>
    <img src='https://u-intosai.org/wp-content/uploads/stm_lms_avatars/stm_lms_avatar2090.jpg?v=1663764813'  class='avatar'>
        
</div>

</div>

<br>
<form action="delete_patients.php" method="POST">
<select class="pure-material-button-contained" name="ids">

<?php

$sql_command = "SELECT identity_number, age, height, weight, gender FROM patients";

$myresult = mysqli_query($db, $sql_command);

    while($id_rows = mysqli_fetch_assoc($myresult))
    {
        $identity_number = $id_rows['identity_number'];
        $age = $id_rows['age'];
        $height = $id_rows['height'];
        $weight = $id_rows['weight'];
        $gender = $id_rows['gender'];
        echo "<option value=$identity_number>". $identity_number. " - ". $age . " - " . $height. " - ". $weight . " - " . $gender  . "</option>";
    }

?>


</select>
<br>
<br>
<div>
<button class="pure-material-button-contained" type="submit">Delete</button>
</div>
</form>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">