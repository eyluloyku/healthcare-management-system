<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>identity_number</th>
				<th>age</th>
				<th>height</th>
				<th>weight</th>
				<th>gender</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['identity_number'])){ 
    $identity_number = $_POST['identity_number']; 
    $sql_statement = "SELECT * FROM patients WHERE identity_number = $identity_number"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
        $identity_number = $id_rows['identity_number'];
        $age = $id_rows['age'];
        $height = $id_rows['height'];
	  $weight = $id_rows['weight'];
	  $gender = $id_rows['gender'];
      echo "<tr> <td>" . $identity_number . "</td><td>" . $age . "</td><td>" . $height . "</td><td>" . $weight . "</td><td>" . $gender . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter ID number.";
}

?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">

