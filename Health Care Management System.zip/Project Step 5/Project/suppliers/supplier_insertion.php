<?php 

include "config.php"; 

if (!empty($_POST['sid'])){ 
    $sid = $_POST['sid']; 
    $location = $_POST['location']; 
    $sql_statement = "INSERT INTO suppliers VALUES ($sid,'$location')"; 

    $result = mysqli_query($db, $sql_statement);
    echo "<div class='box'>
    <div class='upComponent'>
                    <div class='title'>Supplier Insertion Result</div>
            
                    <div class='title'>
                        <img src='https://u-intosai.org/wp-content/uploads/stm_lms_avatars/stm_lms_avatar2090.jpg?v=1663764813'  class='avatar'>
                            
                    </div>
    
                </div>
            
                <br>
                <h2>Supplier Inserted successfully</h2>
        
        
        <h2>Your result is: " . $result . "</h2></div>";
    } 
else 
{
    echo "You did not enter Supplier's ID.";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Instert</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">

