<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>sid</th>
				<th>location</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['location'])){ 
    $location = $_POST['location']; 
    $sql_statement = "SELECT * FROM suppliers WHERE location = '$location'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
        $sid = $id_rows['sid'];
        $location = $id_rows['location'];
        echo "<tr> <td>" . $sid . "</td><td>" . $location . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter your location.";
}

?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">


