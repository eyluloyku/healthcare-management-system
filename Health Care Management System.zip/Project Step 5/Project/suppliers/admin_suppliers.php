<?php 

include "config.php";

?>
<div class='box'>
<div class='upComponent'>
<div class='title'>Select the Supplier to be deleted:</div>

<div class='title'>
    <img src='https://u-intosai.org/wp-content/uploads/stm_lms_avatars/stm_lms_avatar2090.jpg?v=1663764813'  class='avatar'>
        
</div>

</div>

<br>
<form action="delete_suppliers.php" method="POST">
<select class="pure-material-button-contained" name="ids">

<?php

$sql_command = "SELECT * FROM suppliers";

$myresult = mysqli_query($db, $sql_command);

    while($id_rows = mysqli_fetch_assoc($myresult))
    {
        $sid = $id_rows['sid'];
        $location = $id_rows['location'];
        echo "<option value=$sid>". $sid. " ". $location . "</option>";
    }

?>
</select>
<br>
<br>
<div>
<button class="pure-material-button-contained" type="submit">Delete</button>
</div>
</form>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">