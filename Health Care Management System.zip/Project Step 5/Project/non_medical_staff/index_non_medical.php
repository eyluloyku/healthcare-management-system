<?php 

include "config.php"; // Makes mysql connection
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>ssn</th>
				<th>age</th>
				<th>gender</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
$sql_statement = "SELECT * FROM non_medical_staff"; 

$result = mysqli_query($db, $sql_statement); // Executing query

while($row = mysqli_fetch_assoc($result)) { // Iterating the result
    $ssn = $row['ssn']; 
    $age = $row['age']; 
    $gender = $row['gender']; 
    echo "<tr> <td>" . $ssn . "</td><td>" . $age . "</td><td>" . $gender . "</td></tr>"; 
    
} 

?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">

