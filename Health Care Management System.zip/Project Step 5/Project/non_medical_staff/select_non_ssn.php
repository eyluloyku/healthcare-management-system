<?php 

include "config.php"; 
?>
<div class='box'>


	<table>
		<thead>
			<tr>
				<th>ssn</th>
				<th>age</th>
				<th>gender</th>
			</tr>
		</thead>
		<tbody>
        <tr>

<?php
if (!empty($_POST['ssn'])){ 
    $ssn = $_POST['ssn']; 
    $sql_statement = "SELECT * FROM non_medical_staff WHERE ssn = '$ssn'"; 

    $result = mysqli_query($db, $sql_statement);
    while($id_rows = mysqli_fetch_assoc($result))
    {
        $ssn = $id_rows['ssn'];
        $age = $id_rows['age'];
        $gender = $id_rows['gender'];
        echo "<tr> <td>" . $ssn . "</td><td>" . $age . "</td><td>" . $gender . "</td></tr>"; 
    }

} 
else 
{
    echo "You did not enter your name.";
}

?>

</tbody>
	</table>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doc&Delete</title>
    <link rel="stylesheet" href="style_hospital_insertion.css">

